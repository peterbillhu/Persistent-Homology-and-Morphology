clc; clear;
ImageName = 'Topaz_Fu_density_0_7-denoise-denoise.png';
Buff = imread(ImageName);
if (length(size(Buff)) >= 3)
   Buff = rgb2gray(Buff);
end
idx = find(Buff >= 128);
idx_0 = find(Buff < 128);
Buff(idx) = 1;
Buff(idx_0) = 0;
Buff = uint8(255 * int32(Buff));
% Save image
imwrite(Buff,['Bin_',ImageName]);