clear; clc;

%% Step 1 :: loadImage
ImageName = 'noised_img.jpg';
A = imread(ImageName);
ImageForm = 2 %% 1 : 'binary' or 2 : 'grayscale'

%% Step 2 :: Generate DNN model
net = denoisingNetwork('DnCNN');

%% Step 3 :: DNN Denoise
if (ImageForm == 1)
    % Case 1 :: "Binary Images" with three channel
    if (length(size(A)) >= 3)
        A = rgb2gray(A);
    end
    A = Gray_to_Binary(A);   %% to a 0-1 matrix 
    Buff = denoiseImage(uint8(255 * int32(A)),net);
    idx = find(Buff >= 128);
    idx_0 = find(Buff < 128);
    Buff(idx) = 1;
    Buff(idx_0) = 0;
    Buff = uint8(255 * int32(Buff));
    % Save image
    imwrite(Buff,['DNN_denoised_',ImageName]);
else
    if (length(size(A)) >= 3)
       % Case 2 :: Gray-scale Image with three channels
       Buff_R = denoiseImage(A(:,:,1),net);
       Buff_G = denoiseImage(A(:,:,2),net);
       Buff_B = denoiseImage(A(:,:,3),net);
       Buff(:,:,1) = Buff_R;
       Buff(:,:,2) = Buff_G;
       Buff(:,:,3) = Buff_B;
       % Save image
       imwrite(Buff,['DNN_denoised_',ImageName]);
    else
       Buff = denoiseImage(A,net);
       % Save image
       imwrite(Buff,['DNN_denoised_',ImageName]);
    end
end




















