clear;clc;
img1 = imread('cameraman.jpg');
img2 = imread('noised_img-denoise-denoise.jpg');
img2 = rgb2gray(img2);
IOU_of_Grayscale_Images(img1,img2);
