function Score = IOU_of_Grayscale_Images(Img1, Img2)
    %% For RGB images 
  if (length(size(Img1)) == 3 && length(size(Img2)) == 3)  
      Score = zeros(1,3);
      for i = 1 : 255
         for j = 1 : 3
           Buff_1 = thresholding(Img1(:,:,j), i);
           Buff_2 = thresholding(Img2(:,:,j), i);
                   %% R G B three channels
           Score(1,j) = Score(1,j) + IOU(Buff_1, Buff_2);   
         end    
      end
      Score = Score / 255;
      return
  elseif (length(size(Img1)) == 2 && length(size(Img2)) == 2)
      Score = 0;
      for i = 1 : 255
          Buff_1 = thresholding(Img1, i);
          Buff_2 = thresholding(Img2, i);
          Score = Score + IOU(Buff_1, Buff_2);
      end
      Score = Score / 255;
      return
  end
  Score = -1;
end