clear; clc;

%% loadImage

net = denoisingNetwork('DnCNN');

A = imread('Fu.png');
A = imresize(A,0.5);
A = rgb2gray(A);

%% Gray to Binary
A = Gray_to_Binary(A);

% runDIPHA('fil_Fu', A);
% [dims,b,d] = load_persistence_diagram(['fil_Fu', 'PD']);
% Output = [dims,b,d];
%% Replace from DIPHA to Perseus
cd('Perseus');
    runPerseus('tmp', 1 + int32(A));
    PD0 = load('tmp_0.txt');
    PD1 = load('tmp_1.txt');
cd ..;
[m_buff, ~] = size(PD0);
PD0 = [zeros(m_buff,1),PD0];
[m_buff, ~] = size(PD1);
PD1 = [1 + zeros(m_buff,1),PD1];
Output = int32([PD0; PD1]);
%%
GT_beta_0 = size(find(Output(:,1) == 0  | Output(:,1) == -1));
GT_beta_0 = GT_beta_0(1);
GT_beta_1 = size(find(Output(:,1) == 1));
GT_beta_1 = GT_beta_1(1);

imshow(A, []);

for d = 1 : 10
    
    fprintf('d = %f\n', d * 0.1);
    
    density = d * 0.1;
    
    Original_IOUs = [];
    IOUs = [];
    DNN_IOUs = [];
        
    Original_beta_0s = [];
    beta_0s = [];
    DNN_beta_0s = [];
    
    Original_beta_1s = [];
    beta_1s = [];
    DNN_beta_1s = [];
    

    %% Add Noise
    for i = 1 : 1000
        
        %% Add pepper and salts
        Buff = Add_Salt_Pepper(A, density);
        %imshow(A, []);
        score = IOU(A, Buff);
        Original_IOUs = [Original_IOUs, score];
        
%         runDIPHA('fil_Fu', Buff);
%         [dims,b,d] = load_persistence_diagram(['fil_Fu', 'PD']);
%         Output = [dims,b,d];
              %% Replace from DIPHA to Perseus
        cd('Perseus');
            runPerseus('tmp', 1 + int32(Buff));
            PD0 = load('tmp_0.txt');
            PD1 = load('tmp_1.txt');
        cd ..;
        [m_buff, ~] = size(PD0);
        PD0 = [zeros(m_buff,1),PD0];
        [m_buff, ~] = size(PD1);
        PD1 = [1 + zeros(m_buff,1),PD1];
        Output = int32([PD0; PD1]);
              %%
        beta_0 = size(find(Output(:,1) == 0 | Output(:,1) == -1));
        beta_0 = beta_0(1);
        beta_1 = size(find(Output(:,1) == 1));
        beta_1 = beta_1(1);
        
        Original_beta_0s = [Original_beta_0s, beta_0];
        Original_beta_1s = [Original_beta_1s, beta_1];        

        %%以下的code正式release 時要打開
% % % % % % % % % % % % % % % %         %% Do morphology
% % % % % % % % % % % % % % % %         Buff_2 = Do_Morphology(Buff, 10, 0.0007);
% % % % % % % % % % % % % % % %         %imshow(A, []);
% % % % % % % % % % % % % % % %         score = IOU(A, Buff_2);
% % % % % % % % % % % % % % % %         IOUs = [IOUs, score];
% % % % % % % % % % % % % % % %         
% % % % % % % % % % % % % % % % %         runDIPHA('fil_Fu', Buff_2);
% % % % % % % % % % % % % % % % %         [dims,b,d] = load_persistence_diagram(['fil_Fu', 'PD']);
% % % % % % % % % % % % % % % % %         Output = [dims,b,d];
% % % % % % % % % % % % % % % %               %% Replace from DIPHA to Perseus
% % % % % % % % % % % % % % % %         cd('Perseus');
% % % % % % % % % % % % % % % %             runPerseus('tmp', 1 + int32(Buff_2));
% % % % % % % % % % % % % % % %             PD0 = load('tmp_0.txt');
% % % % % % % % % % % % % % % %             PD1 = load('tmp_1.txt');
% % % % % % % % % % % % % % % %         cd ..;
% % % % % % % % % % % % % % % %         [m_buff, ~] = size(PD0);
% % % % % % % % % % % % % % % %         PD0 = [zeros(m_buff,1),PD0];
% % % % % % % % % % % % % % % %         [m_buff, ~] = size(PD1);
% % % % % % % % % % % % % % % %         PD1 = [1 + zeros(m_buff,1),PD1];
% % % % % % % % % % % % % % % %         Output = int32([PD0; PD1]);
% % % % % % % % % % % % % % % %               %%
% % % % % % % % % % % % % % % %         beta_0 = size(find(Output(:,1) == 0 | Output(:,1) == -1));
% % % % % % % % % % % % % % % %         beta_0 = beta_0(1);
% % % % % % % % % % % % % % % %         beta_1 = size(find(Output(:,1) == 1));
% % % % % % % % % % % % % % % %         beta_1 = beta_1(1);
% % % % % % % % % % % % % % % %         
% % % % % % % % % % % % % % % %         beta_0s = [beta_0s, beta_0];
% % % % % % % % % % % % % % % %         beta_1s = [beta_1s, beta_1];        
        
        %% DNN
        Buff_3 = denoiseImage(uint8(255 * int32(Buff)),net);
        idx = find(Buff_3 >= 128);
        idx_0 = find(Buff_3 < 128);
        Buff_3(idx) = 1;
        Buff_3(idx_0) = 0;
        score = IOU(A, Buff_3);
        DNN_IOUs = [DNN_IOUs; score];
        
        %% Replace from DIPHA to Perseus
        cd('Perseus');
            runPerseus('tmp', 1 + int32(Buff_3));
            PD0 = load('tmp_0.txt');
            PD1 = load('tmp_1.txt');
        cd ..;
        [m_buff, ~] = size(PD0);
        PD0 = [zeros(m_buff,1),PD0];
        [m_buff, ~] = size(PD1);
        PD1 = [1 + zeros(m_buff,1),PD1];
        Output = int32([PD0; PD1]);
              %%
        beta_0 = size(find(Output(:,1) == 0 | Output(:,1) == -1));
        beta_0 = beta_0(1);
        beta_1 = size(find(Output(:,1) == 1));
        beta_1 = beta_1(1);
        
        DNN_beta_0s = [DNN_beta_0s, beta_0];
        DNN_beta_1s = [DNN_beta_1s, beta_1];   
        
    end

    old_mu = mean(Original_IOUs)
    old_sigma = std(Original_IOUs)
    
    DNN_mu = mean(DNN_IOUs)
    DNN_sigma = std(DNN_IOUs)

    mu = mean(IOUs)
    sigma = std(IOUs)
    
    original_beta_0_mu = mean(Original_beta_0s)
    original_beta_0_sigma = std(Original_beta_0s)
    
    original_beta_1_mu = mean(Original_beta_1s)
    original_beta_1_sigma = std(Original_beta_1s)
    
    beta_0_mu = mean(beta_0s)
    beta_0_sigma = std(beta_0s)
    
    beta_1_mu = mean(beta_1s)
    beta_1_sigma = std(beta_1s)
    
    DNN_beta_0_mu = mean(DNN_beta_0s)
    DNN_beta_0_sigma = std(DNN_beta_0s)
    
    DNN_beta_1_mu = mean(DNN_beta_1s)
    DNN_beta_1_sigma = std(DNN_beta_1s)
    
end























